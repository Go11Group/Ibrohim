-- find the best performing student in every course
SELECT c.name AS course, s.name AS student_name, max_grades.max_grade
FROM (
    SELECT sc.courseid, MAX(g.mark) AS max_grade
    FROM student_course sc
    JOIN grade g ON sc.id = g.stu_cou_id
    GROUP BY sc.courseid
) AS max_grades
JOIN student_course sc ON max_grades.courseid = sc.courseid
JOIN grade g ON sc.id = g.stu_cou_id AND g.mark = max_grades.max_grade
JOIN student s ON sc.studentid = s.id
JOIN course c ON sc.courseid = c.id;

-- find the average mark among all courses
select c.name as course, round(avg(g.mark),2) as average_mark from course c
join student_course sc on c.id = sc.courseid
join grade g on sc.id = g.stu_cou_id
group by c.name;

-- find the youngest student among all courses
select c.name as course, s.name as youngest_student, min(s.age) from course c
join student_course sc on c.id = sc.courseid
join student s on sc.studentid = s.id
join (
    select courseid, min(age) as min_age from student_course sc
    join student s on sc.studentid = s.id
    group by courseid
) as y_per_c on sc.courseid = y_per_c.courseid and s.age = y_per_c.min_age
group by c.name, s.name;

-- find the course with the highest average mark
select course, round(max(avgMark),2) as highest_mark
from (
    select c.name as course, avg(g.mark) as avgMark from course c
    join student_course sc on sc.courseid = c.id
    join grade g on g.stu_cou_id = sc.id
    group by c.name) as avg_marks
group by course
order by highest_mark desc
limit 1;